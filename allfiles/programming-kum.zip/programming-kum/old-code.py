class Mahsulot:
    def __init__(self, nomi, narxi, miqdori):
        self.nomi = nomi
        self.narxi = narxi
        self.miqdori = miqdori

class Ombor:
    def __init__(self):
        self.mahsulotlar = []

    def mahsulot_qo'shish(self, mahsulot):
        self.mahsulotlar.append(mahsulot)
        print(f"{mahsulot.nomi} mahsuloti omborga qo'shildi.")

    def mahsulot_qidirish(self, nomi):
        for mahsulot in self.mahsulotlar:
            if mahsulot.nomi == nomi:
                return mahsulot
        return None

    def mahsulotlar_ro'yhati(self):
        print("Ombordagi mahsulotlar:")
        for mahsulot in self.mahsulotlar:
            print(f"{mahsulot.nomi} - {mahsulot.narxi} so'm, qolgan miqdori: {mahsulot.miqdori}")

ombor = Ombor()

while True:
    print("\nMahsulotlar ombori")
    print("1. Mahsulot qo'shish")
    print("2. Mahsulot qidirish")
    print("3. Mahsulotlar ro'yhatini ko'rish")
    print("4. Chiqish")

    tanlov = input("Tanlang: ")

    if tanlov == '1':
        nomi = input("Mahsulot nomini kiriting: ")
        narxi = float(input("Mahsulot narxini kiriting: "))
        miqdori = int(input("Mahsulot miqdorini kiriting: "))
        mahsulot = Mahsulot(nomi, narxi, miqdori)
        ombor.mahsulot_qoshish(mahsulot)
    elif tanlov == '2':
        nomi = input("Qidirilayotgan mahsulot nomini kiriting: ")
        mahsulot = ombor.mahsulot_qidirish(nomi)
        if mahsulot:
            print(f"{mahsulot.nomi} - {mahsulot.narxi} so'm, qolgan miqdori: {mahsulot.miqdori}")
        else:
            print("Mahsulot topilmadi.")
    elif tanlov == '3':
        ombor.mahsulotlar_royhati()
    elif tanlov == '4':
        print("Dastur tugadi.")
        break
    else:
        print("Noto'g'ri tanlov! Qaytadan urinib ko'ring.")

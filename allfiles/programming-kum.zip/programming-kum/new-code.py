class Mahsulot:
    def __init__(self, nomi, narxi, miqdori):
        self.nomi = nomi
        self.narxi = narxi
        self.miqdori = miqdori

class Ombor:
    def __init__(self):
        self.mahsulotlar = []

    def mahsulot_qoshish(self, mahsulot):
        self.mahsulotlar.append(mahsulot)
        print(f"{mahsulot.nomi} mahsuloti omborga qo'shildi.")

    def mahsulot_qidirish(self, nomi):
        for mahsulot in self.mahsulotlar:
            if mahsulot.nomi == nomi:
                return mahsulot
        return None

    def mahsulotlar_royhati(self):
        print("Ombordagi mahsulotlar:")
        for mahsulot in self.mahsulotlar:
            print(f"{mahsulot.nomi} - {mahsulot.narxi} so'm, qolgan miqdori: {mahsulot.miqdori}")

    def qolmagan_mahsulotlar(self):
        print("Ombordagi qolmagan mahsulotlar:")
        qolmagan_mahsulotlar_mavjud = False
        for mahsulot in self.mahsulotlar:
            if mahsulot.miqdori == 0:
                qolmagan_mahsulotlar_mavjud = True
                print(f"{mahsulot.nomi} - {mahsulot.narxi} so'm")
        if not qolmagan_mahsulotlar_mavjud:
            print("Omborda qolmagan mahsulotlar yo'q")

    def mahsulotni_update_qilish(self, nomi, yangi_narx, yangi_miqdori):
        mahsulot = self.mahsulot_qidirish(nomi)
        if mahsulot:
            mahsulot.narxi = yangi_narx
            mahsulot.miqdori = yangi_miqdori
            print(f"{mahsulot.nomi} mahsuloti muvaffaqiyatli yangilandi.")
        else:
            print("Mahsulot topilmadi.")

ombor = Ombor()

while True:
    print("\nMahsulotlar ombori")
    print("1. Mahsulot qo'shish")
    print("2. Mahsulot qidirish")
    print("3. Mahsulotlar ro'yhatini ko'rish")
    print("4. Qolmagan mahsulotlar ro'yhatini ko'rish")
    print("5. Mahsulotni yangilash")
    print("6. Chiqish")

    tanlov = input("Tanlang: ")

    if tanlov == '1':
        nomi = input("Mahsulot nomini kiriting: ")
        narxi = float(input("Mahsulot narxini kiriting: "))
        miqdori = int(input("Mahsulot miqdorini kiriting: "))
        mahsulot = Mahsulot(nomi, narxi, miqdori)
        ombor.mahsulot_qoshish(mahsulot)
    elif tanlov == '2':
        nomi = input("Qidirilayotgan mahsulot nomini kiriting: ")
        mahsulot = ombor.mahsulot_qidirish(nomi)
        if mahsulot:
            print(f"{mahsulot.nomi} - {mahsulot.narxi} so'm, qolgan miqdori: {mahsulot.miqdori}")
        else:
            print("Mahsulot topilmadi.")
    elif tanlov == '3':
        ombor.mahsulotlar_royhati()
    elif tanlov == '4':
        ombor.qolmagan_mahsulotlar()
    elif tanlov == '5':
        nomi = input("Yangilayotgan mahsulot nomini kiriting: ")
        yangi_narx = float(input("Yangi narxni kiriting: "))
        yangi_miqdori = int(input("Yangi miqdorni kiriting: "))
        ombor.mahsulotni_update_qilish(nomi, yangi_narx, yangi_miqdori)
    elif tanlov == '6':
        print("Dastur tugadi.")
        break
    else:
        print("Noto'g'ri tanlov! Qaytadan urinib ko'ring.")

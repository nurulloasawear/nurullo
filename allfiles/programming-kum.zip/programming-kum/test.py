import unittest
from admin import Ombor, Mahsulot

class TestOmbor(unittest.TestCase):
    def setUp(self):
        self.ombor = Ombor()

    def test_mahsulot_qoshish(self):
        self.ombor.mahsulot_qoshish(Mahsulot("Olma", 1500, 100))
        self.assertEqual(len(self.ombor.mahsulotlar), 1)

    def test_mahsulot_qidirish(self):
        self.ombor.mahsulot_qoshish(Mahsulot("Olma", 1500, 100))
        mahsulot = self.ombor.mahsulot_qidirish("Olma")
        self.assertIsNotNone(mahsulot)
        self.assertEqual(mahsulot.nomi, "Olma")

    def test_mahsulotni_update_qilish(self):
        self.ombor.mahsulot_qoshish(Mahsulot("Olma", 1500, 100))
        self.ombor.mahsulotni_update_qilish("Olma", 2000, 50)
        mahsulot = self.ombor.mahsulot_qidirish("Olma")
        self.assertEqual(mahsulot.narxi, 2000)
        self.assertEqual(mahsulot.miqdori, 50)

    def test_qolmagan_mahsulotlar(self):
        self.ombor.mahsulot_qoshish(Mahsulot("Olma", 1500, 100))
        self.ombor.mahsulot_qoshish(Mahsulot("Banan", 2000, 0))
        self.ombor.mahsulot_qoshish(Mahsulot("Apelsin", 3000, 50))
        captured_output = io.StringIO()  
        sys.stdout = captured_output
        self.ombor.qolmagan_mahsulotlar()
        sys.stdout = sys.__stdout__
        self.assertIn("Banan", captured_output.getvalue())

if __name__ == '__main__':
    unittest.main()

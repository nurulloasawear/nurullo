import 'package:flutter/material.dart';
// import 'admin_login_page.dart';
import 'product.dart';
import 'add_product_page.dart'; // Make sure to import the AddProductPage

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Product> products = [];
  List<Product> filteredProducts = [];
  String filterCategory = 'All';
  String searchQuery = ''; // Added to keep track of the current search query

  @override
  void initState() {
    super.initState();
    filteredProducts = products;
  }

  void updateProductList(Product newProduct) {
    setState(() {
      products.add(newProduct);
      applyFilters(); // Reapply filters to include the new product
    });
  }

  void applyFilters() {
    setState(() {
      filteredProducts = products.where((product) {
        return (filterCategory == 'All' || product.category == filterCategory) &&
               (searchQuery.isEmpty || product.name.toLowerCase().contains(searchQuery.toLowerCase()));
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Page'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => AddProductPage(onAddProduct: updateProductList),
              ));
            },
          )
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Search',
                suffixIcon: Icon(Icons.search),
              ),
              onChanged: (value) {
                setState(() {
                  searchQuery = value;
                  applyFilters();
                });
              },
            ),
          ),
          DropdownButton<String>(
            value: filterCategory,
            onChanged: (value) {
              setState(() {
                filterCategory = value!;
                applyFilters();
              });
            },
            items: ['All', ...products.map((p) => p.category).toSet()].map((String category) {
              return DropdownMenuItem<String>(
                value: category,
                child: Text(category),
              );
            }).toList(),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredProducts.length,
              itemBuilder: (context, index) {
                return Card(
                  child: ListTile(
                    leading: Image.network(filteredProducts[index].imageUrl),
                    title: Text(filteredProducts[index].name),
                    subtitle: Text('${filteredProducts[index].category} - \$${filteredProducts[index].price}'),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

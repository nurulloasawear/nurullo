package com.example.my_online_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

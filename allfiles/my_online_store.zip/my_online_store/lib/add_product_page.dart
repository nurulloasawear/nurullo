import 'package:flutter/material.dart';
import 'product.dart';

class AddProductPage extends StatefulWidget {
  final Function(Product) onAddProduct;

  AddProductPage({required this.onAddProduct});

  @override
  _AddProductPageState createState() => _AddProductPageState();
}

class _AddProductPageState extends State<AddProductPage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _imageUrlController = TextEditingController();
  String _category = 'General';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add New Product'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Product Name'),
            ),
            TextField(
              controller: _priceController,
              decoration: InputDecoration(labelText: 'Price'),
            ),
            TextField(
              controller: _imageUrlController,
              decoration: InputDecoration(labelText: 'Image URL'),
            ),
            DropdownButton<String>(
              value: _category,
              onChanged: (value) {
                setState(() {
                  _category = value!;
                });
              },
              items: ['General', 'Electronics', 'Clothing', 'Books'].map((String category) {
                return DropdownMenuItem<String>(
                  value: category,
                  child: Text(category),
                );
              }).toList(),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                if (_nameController.text.isNotEmpty && _priceController.text.isNotEmpty && _imageUrlController.text.isNotEmpty) {
                  Product newProduct = Product(
                    name: _nameController.text,
                    category: _category,
                    price: double.parse(_priceController.text),
                    imageUrl: _imageUrlController.text,
                  );
                  widget.onAddProduct(newProduct);
                  Navigator.of(context).pop();
                }
              },
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}

import os
while True:
    ab = ['chrome','hrome','hrom',1]
    a = input("buyruq:")
    if a in ab :
        print("salom")
        os.system('"C:/Program Files/Google/Chrome/Application/chrome.exe"')
        continue
        a = input("buyruq:")